using JuneIDebug.Client.Pages;
using JuneIDebug.Components;
using Microsoft.AspNetCore.Authentication.Negotiate;

var builder = WebApplication.CreateBuilder(args);



builder.Services.AddAuthentication(NegotiateDefaults.AuthenticationScheme)
                .AddNegotiate();

builder.Services.AddAuthorization(opt =>
{
    opt.AddPolicy("PolicyManager", policy => policy.RequireRole("DE-Manager")); // hier k�nnen policies eingef�gt werden
    opt.AddPolicy("PolicyUser", policy => policy.RequireRole("DE-IT-User")); // hier k�nnen policies eingef�gt werden
    opt.AddPolicy("PolicyAdmin", policy => policy.RequireRole("DE-IT-Admin")); // hier k�nnen policies eingef�gt werden
    opt.FallbackPolicy = opt.DefaultPolicy; // no unauthenticated ppl allowed 
});

builder.Services.AddCascadingAuthenticationState();


// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents()
    .AddInteractiveWebAssemblyComponents();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseWebAssemblyDebugging();
}
else
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode()
    .AddInteractiveWebAssemblyRenderMode()
    .AddAdditionalAssemblies(typeof(Counter).Assembly);

app.Run();
